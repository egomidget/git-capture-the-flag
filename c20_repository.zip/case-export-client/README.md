# Case export client

This client retrieves a customer's case export from the test service.
Set CASE_EXPORT_TOKEN in the environment before running client.py.
The service reads the token from the Authorization: Bearer header.

The default lab address is http://127.0.0.1:8765 and the export path is
/c20/export. Set LAB_BASE if you started the lab on another port.
You can make the same request with curl or another HTTP client.

The repository is a supplied local assessment fixture. Its contributors and
their addresses are fictional. There is no remote repository to contact.

All requests for this exercise belong on the local lab.
