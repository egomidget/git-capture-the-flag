import os

API_TOKEN = os.environ["CASE_EXPORT_TOKEN"]
EXPORT_PATH = "/c20/export"
