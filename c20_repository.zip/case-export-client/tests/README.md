# Fixtures

These files describe expected response shapes; they contain no customer data.
An empty items list is a successful export, not an error.
