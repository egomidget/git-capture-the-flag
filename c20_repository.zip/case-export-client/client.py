import json
import os
from urllib.request import Request, urlopen
from config import API_TOKEN, EXPORT_PATH

base = os.environ.get("LAB_BASE", "http://127.0.0.1:8765")
request = Request(base + EXPORT_PATH,
                  headers={"Authorization": "Bearer " + API_TOKEN})
with urlopen(request, timeout=10) as response:
    print(json.dumps(json.load(response), indent=2))
