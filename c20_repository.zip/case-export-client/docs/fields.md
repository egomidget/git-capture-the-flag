# Export fields

The response identifies the exported report and includes its case records.
Dates use ISO 8601.
