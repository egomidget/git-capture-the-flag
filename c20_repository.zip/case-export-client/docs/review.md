# Export review

Check the report identifier, record count and response status.
