# Operations

Requests time out after ten seconds and are not retried automatically.
Check the lab address before retrying. Ctrl+C stops the client.
