# Encoding

Export responses use UTF-8 and application/json.
