# HTTP requests

Send Accept: application/json when requesting an export.
Successful requests return JSON; missing credentials return HTTP 401.
