# Local setup

Use Python 3.10 or later. Start the coursework lab, then set CASE_EXPORT_TOKEN.
Do not add credentials to tracked files. Set LAB_BASE to change the local address.
